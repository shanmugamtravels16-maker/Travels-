# Shanmugam Travels & Tourism — Website Package

This package contains a ready-to-deploy static website for *Shanmugam Travels & Tourism*.

## What's included
- index.html, about.html, services.html, packages.html, contact.html
- style.css, script.js
- logo.svg
- A contact form wired to Formspree (replace with your Formspree form id or use Netlify Forms)

## How to deploy (free options)

### GitHub Pages (recommended)
1. Create a GitHub account if you don't have one.
2. Create a new repository named `yourname.github.io`.
3. Upload all files from this ZIP to the repo (root).
4. Go to Settings → Pages → Source → deploy from `main` branch (`/ (root)`).
5. Your site will be live at `https://yourname.github.io/`.

### Netlify (drag & drop)
1. Create a Netlify account.
2. In the Netlify dashboard, choose "Sites" → "Add new site" → "Deploy manually".
3. Drag and drop the contents of this ZIP.
4. Netlify provides a free `*.netlify.app` subdomain.

### Freenom (free domain) + Netlify/GitHub
1. Register a free domain at https://www.freenom.com (extensions: .tk, .ml, .ga, .cf, .gq).
2. Point the domain to Netlify (follow Netlify's DNS instructions) or configure GitHub Pages custom domain.

## Contact form
- To receive emails from the contact form, either:
  - Sign up for Formspree and replace the `action` in `contact.html` with your Formspree endpoint; or
  - Deploy to Netlify and enable Netlify Forms (add `data-netlify="true"` to the form).

## Need help?
Reply to this message and I can:
- Upload to GitHub and set up GitHub Pages for you
- Deploy to Netlify and connect a free domain
- Customize content, images, SEO, or add booking functionality
