// Simple script for responsive nav toggle
document.addEventListener('DOMContentLoaded', function(){
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('mainNav');
  if(toggle){
    toggle.addEventListener('click', function(){
      var links = nav.querySelectorAll('a');
      for(var i=0;i<links.length;i++){
        if(links[i].style.display === 'inline-block') links[i].style.display = 'none';
        else links[i].style.display = 'inline-block';
      }
    });
  }
});
